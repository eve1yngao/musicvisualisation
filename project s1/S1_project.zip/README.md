** Music Visualiser **

Represents percieved 'loudness' calculated using RMS as the amplitude of a Sine Wave.

Play the program file and select a WAV file on your local drive to start. 